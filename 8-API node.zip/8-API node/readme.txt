Get request: http://localhost:5000/users/getAll
Post request: http://localhost:5000/users/create
Put request: http://localhost:5000/users/edit/<email id>
Delete request: http://localhost:5000/users/delete/<email id>

Uses Nodejs, express and mongodb
The passwords are encrypted using bcrypt.